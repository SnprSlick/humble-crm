def get_wave_orders():
    # Replace with actual GraphQL logic to pull Wave invoices
    return [
        {"id": "WAVE-001", "source": "Wave", "date": "2025-07-10", "total": 540.00},
        {"id": "WAVE-002", "source": "Wave", "date": "2025-07-08", "total": 120.00},
    ]
