def get_bigcommerce_orders():
    # Replace with actual BigCommerce API logic
    return [
        {"id": "BIGC-1001", "source": "BigCommerce", "date": "2025-07-12", "total": 85.00},
        {"id": "BIGC-1002", "source": "BigCommerce", "date": "2025-07-09", "total": 260.00},
    ]
