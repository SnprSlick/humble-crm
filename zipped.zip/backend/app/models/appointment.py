from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from enum import Enum

class AppointmentType(str, Enum):
    DYNO_TUNES = "dyno_tunes"
    MAINTENANCE = "maintenance"
    PROJECT_DROP_OFFS = "project_drop_offs"
    COMPLETION_ESTIMATION = "completion_estimation"
    PERSONAL = "personal"
    BUSINESS = "business"

class AppointmentStatus(str, Enum):
    SCHEDULED = "scheduled"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class AppointmentCreate(BaseModel):
    customer_id: str
    appointment_type: AppointmentType
    title: str
    description: Optional[str] = None
    start_datetime: datetime
    end_datetime: datetime

class AppointmentUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    start_datetime: Optional[datetime] = None
    end_datetime: Optional[datetime] = None
    status: Optional[AppointmentStatus] = None

class AppointmentResponse(BaseModel):
    id: int
    google_calendar_event_id: str
    customer_id: str
    appointment_type: str
    title: str
    description: Optional[str]
    start_datetime: str
    end_datetime: str
    wave_invoice_id: Optional[str]
    invoice_modified: bool
    status: str
    created_at: str
    updated_at: str
    
class AppointmentWithCustomer(AppointmentResponse):
    customer_name: Optional[str] = None
    customer_email: Optional[str] = None